package com.dante.paul.dd5erandomlootgenerator.TypesOfLoot.TableObjects;

/**
 * Created by PaulD on 2015-12-02.
 */
public class GemTableObject extends TableObject {

    public GemTableObject() {
        this.numberOfItem = 1;
    }

}
