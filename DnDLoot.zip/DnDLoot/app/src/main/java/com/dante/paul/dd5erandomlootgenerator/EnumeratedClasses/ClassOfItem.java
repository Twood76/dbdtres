package com.dante.paul.dd5erandomlootgenerator.EnumeratedClasses;

/**
 * Created by PaulD on 2015-12-04.
 */
public enum ClassOfItem {
    ARTorGEM,SPELL,ITEM
}
