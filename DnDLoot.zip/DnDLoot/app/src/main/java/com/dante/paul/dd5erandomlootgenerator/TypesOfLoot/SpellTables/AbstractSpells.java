package com.dante.paul.dd5erandomlootgenerator.TypesOfLoot.SpellTables;

import com.dante.paul.dd5erandomlootgenerator.Dice.Dice;

/**
 * Created by PaulD on 2015-11-30.
 * Abstract object for classes that will hold all the spells for a given class of character
 */
public abstract class AbstractSpells {
    //spells gets the spell list from the given class
    protected String[] spells;
    protected int number;
    Dice d = new Dice();

    public abstract String getSpell (int level);
    public abstract String[] getSpells(int level);

    //method calls the getSpells method of the given class
    //TODO move the spell selection into the getSpells method (maybe rename it getSpell)
    public String getSpell(int level, AbstractSpells abstractSpells) {
        switch (level) {
            case 0:
                spells = getSpells(0);
                break;
            case 1:
                spells = getSpells(1);
                break;
            case 2:
                spells = getSpells(2);
                break;
            case 3:
                spells = getSpells(3);
                break;
            case 4:
                spells = getSpells(4);
                break;
            case 5:
                spells = getSpells(5);
                break;
            case 6:
                spells = getSpells(6);
                break;
            case 7:
                spells = getSpells(7);
                break;
            case 8:
                spells = getSpells(8);
                break;
            default:
                spells = getSpells(9);
                break;
        }
        number = spells.length;
        number = d.roll(number)-1;
        return spells[number];
    }
}
