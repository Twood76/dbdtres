package com.dante.paul.dd5erandomlootgenerator.TypesOfLoot.SpellTables;

/**
 * Created by PaulD on 2015-11-30.
 */
public interface Spells {
}
