package com.dante.paul.dd5erandomlootgenerator.EnumeratedClasses;

/**
 * Created by pdante on 5/31/2018.
 */

public enum TypeOfItem {
    SHIELD
}
