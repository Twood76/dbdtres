package com.dante.paul.dd5erandomlootgenerator.TreasureCreationClasses;

/**
 * Created by PaulD on 2015-11-20.
 */
public interface TreasureTable {
    void generateTreasure();
}
