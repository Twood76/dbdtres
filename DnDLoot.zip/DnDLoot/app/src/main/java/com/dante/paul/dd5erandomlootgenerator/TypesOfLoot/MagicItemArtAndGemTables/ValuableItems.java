package com.dante.paul.dd5erandomlootgenerator.TypesOfLoot.MagicItemArtAndGemTables;

import com.dante.paul.dd5erandomlootgenerator.TypesOfLoot.TableObjects.TableObject;

/**
 * Created by PaulD on 2015-11-23.
 */
public abstract class ValuableItems {
    public abstract TableObject getItem(int value);
    
}
