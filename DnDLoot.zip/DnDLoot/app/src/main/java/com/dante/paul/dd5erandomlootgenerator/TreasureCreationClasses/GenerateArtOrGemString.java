package com.dante.paul.dd5erandomlootgenerator.TreasureCreationClasses;

import com.dante.paul.dd5erandomlootgenerator.EnumeratedClasses.ClassOfItem;

/**
 * Created by PaulD on 2015-12-04.
 */
public class GenerateArtOrGemString extends AbstractGeneratedStrings {

    public GenerateArtOrGemString() {
        classOfItem = ClassOfItem.ARTorGEM;
    }
}
