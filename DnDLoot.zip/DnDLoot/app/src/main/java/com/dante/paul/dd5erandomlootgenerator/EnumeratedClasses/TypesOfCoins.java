package com.dante.paul.dd5erandomlootgenerator.EnumeratedClasses;

/**
 * Created by PaulD on 2015-11-20.
 */
public final class TypesOfCoins {
    public static final String COPPER = "cp";
    public static final String SILVER = "sp";
    public static final String GOLD = "gp";
    public static final String ELECTUM = "ep";
    public static final String PLATINUM = "pp";
}
