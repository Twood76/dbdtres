package com.dante.paul.dd5erandomlootgenerator.EnumeratedClasses;

/**
 * Created by PaulD on 2015-11-20.
 */
public enum ChallengeRating {
    ZERO, FIVE, ELEVEN, SEVENTEEN
}
